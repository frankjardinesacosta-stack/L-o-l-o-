# Bot Telegram SENSI OG

El Worker comparte la misma tabla D1 `license_keys` que valida la aplicación.

## Comandos
- `/start` y `/help`: instrucciones.
- `/key` o `/buy`: los usuarios reciben el aviso de compra; no se entrega una Key sin pago confirmado.
- `/gen 1`: solo el administrador (Telegram ID `8833269908`) genera Keys gratis y las recibe en su chat privado.
- `/paid ID_TELEGRAM`: solo el administrador; genera una Key y se la envía al ID indicado. Ejecutar únicamente después de comprobar el pago por fuera del bot.
- `/status`: resumen de Keys.

Las Keys creadas por `/gen`, `/paid` y el panel web se guardan en `license_keys`, la misma base de datos que consulta la app. Cada Key es de un solo dispositivo y dura 30 días desde su primera activación. Los usuarios normales no pueden generar Keys.

## Activación (requiere tu cuenta Cloudflare)
1. En `cloudflare/wrangler.toml`, reemplaza `REEMPLAZAR_ID_D1` por el ID real de D1.
2. Ejecuta `wrangler d1 execute panther-ios-test --remote --file=schema.sql`.
3. Configura los secretos sin escribirlos en el código: `wrangler secret put ADMIN_KEY`, `wrangler secret put TELEGRAM_BOT_TOKEN` y `wrangler secret put TELEGRAM_WEBHOOK_SECRET`. Usa un secreto webhook aleatorio largo.
4. Ejecuta `wrangler deploy` y copia la URL `https://...workers.dev`.
5. Registra el webhook desde un equipo seguro (sustituye los valores localmente):
   `curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" -d "url=https://<WORKER>/telegram/webhook" -d "secret_token=<WEBHOOK_SECRET>"`
6. En `ThreeOneOSFive/Info.plist`, cambia `PantherAPIBaseURL` por la URL HTTPS real del Worker antes de compilar.

**Importante:** esta carpeta no puede activar por sí sola el bot ni crear la base de datos remota. El despliegue, los secretos, el webhook y la URL real requieren acceso a tu cuenta Cloudflare y al token privado del bot. No publiques esos valores en GitHub.

El comando `/paid` no verifica pagos automáticamente: entrega la Key solo cuando tú, como administrador, hayas confirmado el pago manualmente. No hay pasarela de pago conectada.
