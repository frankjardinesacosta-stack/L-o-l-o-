# Desplegar el servidor SENSI OG en Render

Este proyecto usa PostgreSQL persistente de Render; no uses SQLite ni un disco efímero. El Blueprint `render.yaml` crea un Web Service y una base de datos PostgreSQL. Los planes indicados son de pago; revisa el costo en Render antes de confirmar.

## Pasos
1. Sube este ZIP a tu repositorio GitHub (o actualiza el repo con estos archivos).
2. En Render elige **New → Blueprint** y conecta el repositorio.
3. Render leerá `render.yaml`. Revisa los planes y costos de servicio y base de datos antes de aplicar.
4. Cuando pida secretos, introduce:
   - `ADMIN_KEY`: una clave larga aleatoria de administrador para el panel y acceso admin de la app.
   - `TELEGRAM_BOT_TOKEN`: token privado de @SensiOG7_bot, obtenido de BotFather. Nunca lo subas a GitHub ni lo compartas en el chat.
   - `TELEGRAM_WEBHOOK_SECRET`: cadena aleatoria larga (solo letras y números).
   `TELEGRAM_ADMIN_ID` ya está configurado como `8833269908`.
5. Despliega. Copia la URL HTTPS `https://sensi-og-keys.onrender.com` (puede variar según disponibilidad del nombre).
6. En el servicio Render, abre **Shell** o usa una terminal segura y registra el webhook con:
   `curl -X POST "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/setWebhook" -d "url=$RENDER_EXTERNAL_URL/telegram/webhook" -d "secret_token=$TELEGRAM_WEBHOOK_SECRET"`
   Las variables privadas deben estar disponibles en esa terminal. Si no, registra el webhook desde una terminal local segura; nunca pegues el token en GitHub.
7. Actualiza `PantherAPIBaseURL` en `ThreeOneOSFive/Info.plist` con la URL HTTPS real del servicio y vuelve a compilar la app.
8. Prueba `https://TU-SERVICIO.onrender.com/health`; debe responder `{"ok":true,...}`.
9. En Telegram, abre el bot y pulsa Start. Prueba `/gen 1` desde el ID administrador. Para un comprador, confirma manualmente el pago y luego usa `/paid ID_TELEGRAM`.

## Reglas
- Solo el ID `8833269908` puede usar `/gen`, `/paid` y `/status`.
- Los usuarios normales reciben instrucciones para comprar; no se les genera una Key por `/key`.
- `/paid ID` crea y envía una Key después de que el administrador confirme el pago fuera del bot. No existe verificación automática de pagos.
- Las Keys se comparten en PostgreSQL con el endpoint que valida la aplicación; una Key normal dura 30 días desde la primera activación y queda vinculada a un dispositivo.

## Limitación actual
El endpoint de descarga de patches devuelve HTTP 501 porque el ZIP original no incluye un servicio real de archivos de patches. La validación y catálogo de patches sí tienen endpoints.
